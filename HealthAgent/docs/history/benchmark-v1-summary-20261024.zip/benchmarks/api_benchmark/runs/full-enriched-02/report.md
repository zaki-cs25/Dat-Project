# Benchmark report

Run: 70d0352f-1719-48a3-883b-f1b3af1e556f

Completed care operations: 13
Failed care operations: 17
Graded completed outputs: 13
All-attempt quality: 30.99735666666667

Null quality means completed outputs still need valid judgments. Draft clinical rubrics require independent review.
See report.json for performance distributions, stage usage, paired comparisons and coverage.
